@extends('admin.master')

@section('page_header')
  Dashboard
@endsection

@section('page_title')
 Dashboard
@endsection

@section('content')
 Dashboard
@endsection