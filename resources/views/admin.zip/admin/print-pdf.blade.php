 @inject('data','App\Helps')
@extends('admin.master')
@section('title')

@stop
@section('page_header')
<a><i class="fa fa-tasks"></i></a> Print Pdf 
@stop
@section('content')
  <!-- Content Wrapper. Contains page content -->
<section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
          <div class="row invoice-info">
     <section class="invoice">
      <div class="row">
        
        <!-- /.col -->
        <div class="col-md-8">
         <form class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <div class="checkbox">
                      <label>
                        <input type="radio" id="archive"  name="archive" value="1" > Redacted

                      </label>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <div class="checkbox">
                      <label>
                        <input type="radio" id="archive"  name="archive" value="1" > Full
                      </label>
                    </div>
                  </div>
                </div>
                  <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <div class="checkbox">
                      <label>
                        <input type="checkbox" id="archive"  name="archive" value="1" > Print associate Doc
                      </label>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Set Status</label>

                  <div class="col-sm-6">
                    <select name="status" id="status" onchange="updateStatus(this)" class="form-control" id="inputEmail3" placeholder="">
                       <option value="1">All</option>
                       <option value="1">Active</option>
                      <option value="2">Short Listed</option>
                    <select>
                  </div>
                </div>
                
               
              </div>
              
            </form>
        </div>
      </div>
    </section>
        <!-- /.col -->
      </div>
            <div class="box-body">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th><input type="checkbox" value="" id="checkAll"></th>
                  <th>Letter</th>
                  <th>Name</th>
                </tr>
                </thead>
                <tbody>
               @foreach($appliedId as $val)
                @php
                $personalInformation =  $data->personalInformationdetails($val->user_id,$val->job_id);
                
                @endphp
                <tr>
                  <td><input type="checkbox" name=""></td>
                  <td>{{ $val->letter }}</td>
                  <td>{{ $personalInformation->fore_name }}</td>
                </tr>
                  @endforeach
                </tfoot>
              </table>
              <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->


            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </section>
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
      <script type="text/javascript">
        
       $(document).ready(function() {

         $("#checkAll").click(function () {
     $('input:checkbox').not(this).prop('checked', this.checked);
 });
       }) 

      </script>

  @stop
